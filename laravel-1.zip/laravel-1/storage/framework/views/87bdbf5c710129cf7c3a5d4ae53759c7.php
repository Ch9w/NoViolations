<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel='stylesheet' href="<?php echo e(asset('css/head.css')); ?>"/>
    <link rel='stylesheet' href="<?php echo e(asset('css/main.css')); ?>"/>
    <link rel='stylesheet' href="<?php echo e(asset('css/footer.css')); ?>"/>
</head>
<body>
    <div>
        <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class='statements'>
            <h2 style='text-align:center;'>Мои заявления</h2>
            <h3>Фильтрация</h3>
            <form method='POST' action='mystatement'>
                <?php echo csrf_field(); ?>
                <select name='filter'>
                    <option value='новое'>все</option>
                    <option value='новое'>новое</option>
                    <option value='подтверждено'>подтверждено</option>
                    <option value='отклонено'>отклонено</option>
                </select>
                <input style='width:fit-content; padding: 4px 14px 4px 14px' type='submit' value='Поиск'>
            </form>
            <br>
            <?php $__currentLoopData = $statements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $statement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($statement->id_user == Auth::id()): ?>
                <div class='statement'>
                    <div>
                        <div><b>Номер:</b> <?php echo e($statement->number); ?></div>
                    </div>
                    <div>
                        <div><b>Статус:</b> <?php echo e($statement->status); ?></div>
                    </div>
                    <div>
                        <div><b>Описание</b> <br> <?php echo e($statement->description); ?></div>
                    </div>
                <?php endif; ?>
                </div>
                <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div>
        <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</body>
</html><?php /**PATH C:\OSPanel\domains\lomov\NoViolations\laravel\resources\views/mystatement.blade.php ENDPATH**/ ?>