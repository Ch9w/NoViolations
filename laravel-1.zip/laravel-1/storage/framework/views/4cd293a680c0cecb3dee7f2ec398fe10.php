<footer>
    <div class="footer-1">
        <a href='#'>Политика конфиденциальности</a>
    </div>
    <div class="footer-2">
        <a href='#'>Пользовательское соглашение</a>
    </div>
</footer><?php /**PATH D:\Programs\OSPanel\domains\laravel\resources\views/footer.blade.php ENDPATH**/ ?>