<footer>
    <div>
        <a href='#'>Политика конфиденциальности</a>
    </div>
    <div>
        <a href='#'>Пользовательское соглашение</a>
    </div>
</footer><?php /**PATH C:\OSPanel\domains\lomov\NoViolations\laravel\resources\views/footer.blade.php ENDPATH**/ ?>