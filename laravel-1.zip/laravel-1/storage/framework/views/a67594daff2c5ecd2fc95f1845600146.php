<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel='stylesheet' href="<?php echo e(asset('css/head.css')); ?>" />
    <link rel='stylesheet' href="<?php echo e(asset('css/main.css')); ?>" />
    <link rel='stylesheet' href="<?php echo e(asset('css/footer.css')); ?>" />
</head>

<body>
    <div>
        <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class='statements'>
            <h2 style='text-align:center;'>Мои заявления</h2>
            <h3>Фильтрация</h3>
            <form method='POST' action='mystatement'>
                <?php echo csrf_field(); ?>
                <select id="filter" name='filter'>
                    <option value='все' selected>все</option>
                    <option value='новое'>Новые</option>
                    <option value='подтверждено'>Подтверждённые</option>
                    <option value='отклонено'>Отклонённые</option>
                </select>
                <input style='width:fit-content; padding: 4px 14px 4px 14px' type='submit' value='Поиск'>
            </form>
            <br>
            <?php $__currentLoopData = $statements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $statement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class='statement'>
                    <div>
                        <div><b>Номер:</b> <?php echo e($statement->number); ?></div>
                    </div>
                    <div>
                        <div><b>Статус:</b> <?php echo e($statement->status); ?></div>
                    </div>
                    <div>
                        <div><b>Описание</b> <br> <?php echo e($statement->description); ?></div>
                    </div>
                </div>
                <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div>
        <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script type="text/javascript">
    $("#filter").val("<?php
        if (isset($_POST['filter'])) {
            echo $_POST['filter'];
        }
    ?>");
</script>

</html>
<?php /**PATH D:\Programs\OSPanel\domains\laravel\resources\views/mystatement.blade.php ENDPATH**/ ?>