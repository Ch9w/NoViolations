<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel='stylesheet' href="<?php echo e(asset('css/head.css')); ?>"/>
    <link rel='stylesheet' href="<?php echo e(asset('css/authorization.css')); ?>"/>
    <link rel='stylesheet' href="<?php echo e(asset('css/footer.css')); ?>"/>

</head>
<body>
    <div>
        <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class='auth'>
            <h2 style='text-align:center;'>Авторизация</h2>
            <form method='POST' action='authorization'>
                <?php echo csrf_field(); ?>
                <table>
                    <tr>
                        <td>Логин</td>
                        <td>
                            <input type='text' name='login' placeholder='Логин' value="<?php if (isset($_POST['login'])) echo $_POST['login']; ?>">
                        </td>
                    </tr>
                    <tr>
                        <td>Пароль</td>
                        <td><input type='password' name='password' placeholder='Пароль' value="<?php if (isset($_POST['password'])) echo $_POST['password']; ?>"></td>
                    </tr>
                    <tr>
                        <td colspan='2'><a href="<?php echo e(route('registration')); ?>">Нет аккаунта?</a></td>
                    </tr>
                    <tr>
                        <td colspan='2'><input type='submit' value='Авторизоваться'></td>
                    </tr>
                    <tr>
                        <td colspan='2'>
                            <?php $__errorArgs = ['error'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
    <div>
        <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</body>
</html><?php /**PATH D:\Programs\OSPanel\domains\laravel\resources\views/authorization.blade.php ENDPATH**/ ?>