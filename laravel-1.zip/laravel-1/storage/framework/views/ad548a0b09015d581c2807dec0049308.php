<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel='stylesheet' href="<?php echo e(asset('css/head.css')); ?>"/>
    <link rel='stylesheet' href="<?php echo e(asset('css/main.css')); ?>"/>
    <link rel='stylesheet' href="<?php echo e(asset('css/footer.css')); ?>"/>
</head>
<body>
    <div>
        <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class='main'>
            <h2>Добавить заявку</h2>
                <form method='POST' action='addstatement'>
                    <?php echo csrf_field(); ?>
                    <table>
                        <tr>
                            <td>Номер автомобиля</td>
                            <td><input type='text' name='number' value="<?php if (isset($_POST['number'])) echo $_POST['number']; ?>"></td>
                        </tr>
                        <tr>
                            <td>Описание проблемы</td>
                            <td><textarea cols='40' rows='10' name='description'><?php if (isset($_POST['description'])) echo $_POST['description']; ?></textarea></td>
                        </tr>
                        <tr>
                            <td colspan='2'><input type='submit' value='Добавить'></td>
                        </tr>
                        <tr>
                        <td colspan='2'>
                            <?php $__errorArgs = ['error'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                    </tr>

                    </table>
                </form>
            </h2>
        </div>
    </div>
    <div>
        <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</body>
</html><?php /**PATH C:\OSPanel\domains\lomov\NoViolations\laravel\resources\views/addstatement.blade.php ENDPATH**/ ?>