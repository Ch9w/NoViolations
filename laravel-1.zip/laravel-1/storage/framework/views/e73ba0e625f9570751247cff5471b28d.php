<header>
    <div><a href="<?php echo e(route('main')); ?>"><img src="<?php echo e(asset('images/logo.png')); ?>"></a></div>

        <?php if(Auth::check()): ?>
        <div><a href="<?php echo e(route('addstatement')); ?>">Создать заявку</a></div>
        <div><a href="<?php echo e(route('mystatement')); ?>">Мои заявки</a></div>
        <div><a href="<?php echo e(route('logout')); ?>">Выйти</a></div>
        <?php else: ?>
        <div><a href="<?php echo e(route('authorization')); ?>">Войти</a></div>
        <?php endif; ?>
</header><?php /**PATH C:\OSPanel\domains\lomov\NoViolations\laravel\resources\views/header.blade.php ENDPATH**/ ?>