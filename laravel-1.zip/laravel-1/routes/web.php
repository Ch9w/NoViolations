<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
Route::get('/', [Controller::class, 'registration']);
Route::get('/registration', [Controller::class, 'registration'])->name('registration');
Route::post('/registration', [Controller::class, 'registration']);

Route::get('/authorization', [Controller::class, 'authorization'])->name('authorization');
Route::post('/authorization', [Controller::class, 'authorization']);

Route::middleware(['auth'])->group(function () {
    Route::get('/main', [Controller::class, 'main'])->name('main');
    Route::get('/addstatement', [Controller::class, 'addstatement'])->name('addstatement');
    Route::post('/addstatement', [Controller::class, 'addstatement']);

    Route::get('/mystatement', [Controller::class, 'mystatement'])->name('mystatement');
    Route::post('/mystatement', [Controller::class, 'mystatement']);

    Route::get('/logout', function() {
        Auth::logout();
        return redirect()->route('authorization');
    })->name('logout');

    Route::get('/admin', [Controller::class, 'admin'])->name('admin');
    Route::post('/admin', [Controller::class, 'admin']);
});
