<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel='stylesheet' href="{{asset('css/head.css')}}"/>
    <link rel='stylesheet' href="{{asset('css/main.css')}}"/>
    <link rel='stylesheet' href="{{asset('css/footer.css')}}"/>
</head>
<body>
    <div>
        @include('header')
        <div class='main'>
            <h2 style="text-align: center">Добавить заявку</h2>
                <form method='POST' action='addstatement'>
                    @csrf
                    <table>
                        <tr>
                            <td>Номер автомобиля</td>
                            <td><input class="add" type='text' name='number' value="@php if (isset($_POST['number'])) echo $_POST['number']; @endphp"></td>
                        </tr>
                        <tr>
                            <td>Описание проблемы</td>
                            <td><textarea cols='40' rows='10' name='description'>@php if (isset($_POST['description'])) echo $_POST['description']; @endphp</textarea></td>
                        </tr>
                        <tr>
                            <td colspan='2'><input type='submit' value='Добавить'></td>
                        </tr>
                        <tr>
                        <td colspan='2'>
                            @error('error')
                                {{$message}}
                            @enderror
                        </td>
                    </tr>

                    </table>
                </form>
            </h2>
        </div>
    </div>
    <div>
        @include('footer')
    </div>
</body>
</html>