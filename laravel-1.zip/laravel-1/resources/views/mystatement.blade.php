<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel='stylesheet' href="{{ asset('css/head.css') }}" />
    <link rel='stylesheet' href="{{ asset('css/main.css') }}" />
    <link rel='stylesheet' href="{{ asset('css/footer.css') }}" />
</head>

<body>
    <div>
        @include('header')
        <div class='statements'>
            <h2 style='text-align:center;'>Мои заявления</h2>
            <h3>Фильтрация</h3>
            <form method='POST' action='mystatement'>
                @csrf
                <select id="filter" name='filter'>
                    <option value='все' selected>все</option>
                    <option value='новое'>Новые</option>
                    <option value='подтверждено'>Подтверждённые</option>
                    <option value='отклонено'>Отклонённые</option>
                </select>
                <input style='width:fit-content; padding: 4px 14px 4px 14px' type='submit' value='Поиск'>
            </form>
            <br>
            @foreach ($statements as $statement)
                <div class='statement'>
                    <div>
                        <div><b>Номер:</b> {{ $statement->number }}</div>
                    </div>
                    <div>
                        <div><b>Статус:</b> {{ $statement->status }}</div>
                    </div>
                    <div>
                        <div><b>Описание</b> <br> {{ $statement->description }}</div>
                    </div>
                </div>
                <br>
            @endforeach
        </div>
    </div>
    <div>
        @include('footer')
    </div>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script type="text/javascript">
    $("#filter").val("@php
        if (isset($_POST['filter'])) {
            echo $_POST['filter'];
        }
    @endphp");
</script>

</html>
