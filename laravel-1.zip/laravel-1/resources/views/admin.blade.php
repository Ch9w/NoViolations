<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel='stylesheet' href="{{ asset('css/head.css') }}" />
    <link rel='stylesheet' href="{{ asset('css/main.css') }}" />
    <link rel='stylesheet' href="{{ asset('css/footer.css') }}" />
</head>

<body>
    <div>
        @include('header')
        <br>
        <div class='statements'>
            @foreach ($statements as $statement)
                <form action="admin" method="POST">
                    <input name="thisstatement" value="{{$statement->id}}" hidden>
                    @csrf
                    <div class='statement'>
                        <div>
                            <div><b>ФИО:</b> {{ $users->find($statement->id_user)->FIO }}</div>
                        </div>
                        <div>
                            <div><b>Номер:</b> {{ $statement->number }}</div>
                        </div>
                        <div>
                            <div><b>Статус:</b> {{ $statement->status }}</div>
                        </div>
                        <div>
                            <div><b>Описание</b> <br> {{ $statement->description }}</div>
                        </div>
                        <div>
                            <select name='status'>
                                <option value='новое'>Новая</option>
                                <option value='подтверждено'>Подтвердить</option>
                                <option value='отклонено'>Отклонить</option>
                            </select>
                            <input style="width: fit-content" type="submit" value="Изменить статус">
                        </div>
                    </div>
                    <br>
                </form>
            @endforeach
        </div>
    </div>
    <div>
        @include('footer')
    </div>
</body>

</html>
