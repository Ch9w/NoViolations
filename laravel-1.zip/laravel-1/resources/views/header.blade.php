<header>
    <div><a href="{{route('main')}}"><img src="{{asset('images/logo.png')}}"></a></div>

        @if(Auth::check())
        <div><a href="{{route('addstatement')}}">Создать заявку</a></div>
        <div><a href="{{route('mystatement')}}">Мои заявки</a></div>
        <div><a href="{{route('logout')}}">Выйти</a></div>
        @else
        <div><a href="{{route('authorization')}}">Войти</a></div>
        @endif
</header>