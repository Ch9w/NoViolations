<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use App\Models\User;
use App\Models\statement;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class Controller extends BaseController
{
    use AuthorizesRequests, ValidatesRequests;
    function authorization(Request $request)
    {
        if (Auth::check()) {
            return redirect()->route('main');
        }
        if ($request->method() == 'GET') {
            return view('authorization');
        }
        if ($request->method() == 'POST') {
            if ($request->login == null) {
                return view('authorization')->withErrors(['error' => 'Введите логин']);
            }
            if ($request->password == null) {
                return view('authorization')->withErrors(['error' => 'Введите пароль']);
            }
            $login = $request->login;
            $password = $request->password;
            $credentials = $request->validate([
                'login' => 'required',
                'password' => 'required'
            ]);
            if (Auth::attempt($credentials)) {
                return redirect()->route('main');
            } else {
                return view('authorization')->withErrors(['error' => 'Логин или пароль не совпадает']);
            }

            return redirect()->route('main');
        }
    }

    function registration(Request $request)
    {
        if (Auth::check()) {
            return redirect()->route('main');
        }
        if ($request->method() == 'GET') {
            return view('registration');
        }
        if ($request->method() == 'POST') {
            if (
                $request->login == null ||
                $request->email == null ||
                $request->phonenumber == null ||
                $request->FIO == null ||
                $request->password == null ||
                $request->repeatpassword == null
            ) {
                return view('registration')->withErrors(['error' => 'Заполните все поля']);
            }
            if (strlen($request->login) < 4) {
                return view('registration')->withErrors(['error' => 'Логин должен быть минимум 4 символа']);
            }
            $arrFIO = explode(" ", $request->FIO);
            if (count($arrFIO) != 3) {
                return view('registration')->withErrors(['error' => 'Введите Фамилию Имя Отчество через пробел']);
            }
            if (strlen($request->password) < 6) {
                return view('registration')->withErrors(['error' => 'Пароль должен быть минимум 6 символов']);
            }
            if ($request->password != $request->repeatpassword) {
                return view('registration')->withErrors(['error' => 'Пароли должны совпадать']);
            }

            if (User::where('login', $request->login)->first()) {
                return view('registration')->withErrors(['error' => 'Пользователь с таким логином уже зарегистрирован']);
            }
            if (User::where('login', $request->email)->first()) {
                return view('registration')->withErrors(['error' => 'Пользователь с таким email уже зарегистрирован']);
            }
            if (User::where('login', $request->phonenumber)->first()) {
                return view('registration')->withErrors(['error' => 'Пользователь с таким номером телефона уже зарегистрирован']);
            }
            $newuser = new User();
            $newuser->login = $request->login;
            $newuser->email = $request->email;
            $newuser->phonenumber = $request->phonenumber;
            $newuser->FIO = $request->FIO;
            $newuser->password = $request->password;
            $newuser->save();
            $user = User::where('login', $request->login)->first();
            Auth::login($user);
            return redirect()->route('main');
        }
    }
    function main()
    {
        $users = User::get();
        $adminuser = User::where('login', 'copp')->first();
        if (Auth::id() == $adminuser->id) {
            return redirect()->route('admin');
        }
        return view('main', ['users' => $users]);
    }
    function addstatement(Request $request)
    {
        $users = User::get();
        if ($request->method() == "GET") {
            return view('addstatement', ['users' => $users]);
        }
        if ($request->method() == "POST") {
            if ($request->number == null) {
                return view('addstatement', ['users' => $users])->withErrors(['error' => 'Введите номер автомобиля']);
            }
            if ($request->description == null) {
                return view('addstatement', ['users' => $users])->withErrors(['error' => 'Введите описание']);
            }
            $newstatement = new statement();
            $newstatement->number = $request->number;
            $newstatement->description = $request->description;
            $newstatement->id_user = Auth::id();
            $newstatement->status = 'новое';
            $newstatement->save();
            return redirect()->route('mystatement');
        }
    }
    function mystatement(Request $request)
    {
        $users = User::get();
        if ($request->method() == "GET") {
            $statements = statement::where("id_user", Auth::id())->get();
            return view('mystatement', ['users' => $users, 'statements' => $statements]);
        }
        if ($request->method() == "POST") {
            if ($request->filter == 'все') {
                $statements = statement::where("id_user", Auth::id())->get();
            } else {
                $statements = statement::where("id_user", Auth::id())->where('status', $request->filter)->get();
            }
            return view('mystatement', ['users' => $users, 'statements' => $statements]);
        }
    }
    function admin(Request $request)
    {
        $users = User::get();
        $adminuser = User::where('login', 'copp')->first();
        if (Auth::id() == $adminuser->id) {
            if ($request->method() == 'GET') {
                $statements = statement::where("status", 'новое')->get();
                return view('admin', ['users' => $users, 'statements' => $statements]);
            }
            if ($request->method() == 'POST') {
                $thisstatement = statement::find($request->thisstatement);
                $thisstatement->status = $request->status;
                $thisstatement->save();
                return redirect()->route('admin');
            }
        }
        else {
            return redirect()->route('main');
        }
    }
}
